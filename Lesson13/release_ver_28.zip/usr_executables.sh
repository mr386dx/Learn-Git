#!/bin/bash
find /usr/bin/ -perm 755 1> usr_executables.md

