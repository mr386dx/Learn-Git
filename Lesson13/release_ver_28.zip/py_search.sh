#!/bin/bash
find / -type f -name "*.py" 1> py_scripts.md 2> py_errors.md


